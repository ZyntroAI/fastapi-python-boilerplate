#!/usr/bin/env bash
set -euo pipefail
if command -v trivy >/dev/null 2>&1; then
  trivy fs --severity HIGH,CRITICAL --ignore-unfixed .
else
  echo "trivy is required for local security scanning" >&2
  exit 1
fi
