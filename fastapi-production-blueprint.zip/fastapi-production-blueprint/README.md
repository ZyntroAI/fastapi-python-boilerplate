# Production FastAPI Blueprint

Production-oriented FastAPI skeleton with OAuth2/PKCE foundations, Docker, GitHub Actions, GHCR, and Kubernetes.

## Local

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
make check
make run
```

API health: `GET /health`

## Docker

```bash
docker compose up --build
```

## Kubernetes

Replace the example image and host, and inject `JWT_SECRET` through a real secret manager. Do not commit production secrets.

```bash
kubectl apply -f deploy/kubernetes/
```

## Security notes

- OAuth state must be persisted server-side with a short TTL in production.
- Replace the demo OAuth callback code exchange with the provider's token endpoint.
- Use a single JWT library.
- Do not place access tokens in URLs.
- Use immutable container tags such as the Git SHA.
- Prefer an external secret manager for production credentials.
