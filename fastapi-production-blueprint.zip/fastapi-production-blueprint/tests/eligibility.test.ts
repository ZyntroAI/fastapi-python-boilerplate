import { describe, expect, it } from "vitest";

type User = { role?: string; active: boolean };

function isEligible(user: User): boolean {
  return user.active && user.role !== "blocked";
}

describe("eligibility", () => {
  it("accepts active users", () => {
    expect(isEligible({ active: true })).toBe(true);
  });

  it("rejects blocked users", () => {
    expect(isEligible({ active: true, role: "blocked" })).toBe(false);
  });

  it("rejects inactive users", () => {
    expect(isEligible({ active: false })).toBe(false);
  });
});
