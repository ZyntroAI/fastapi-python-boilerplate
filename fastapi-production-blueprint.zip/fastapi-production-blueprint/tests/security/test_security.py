from app.core.security import verify_state

def test_state_matches():
    assert verify_state("abc", "abc")

def test_state_mismatch():
    assert not verify_state("abc", "xyz")

def test_missing_state_rejected():
    assert not verify_state("", "abc")
    assert not verify_state("abc", "")
