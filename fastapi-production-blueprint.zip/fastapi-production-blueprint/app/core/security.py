from datetime import datetime, timedelta, timezone
import hmac
from jose import jwt
from app.core.config import settings

def create_access_token(subject: dict) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        **subject,
        "iat": now,
        "exp": now + timedelta(minutes=settings.access_token_minutes),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)

def verify_state(received: str, expected: str) -> bool:
    return bool(received) and bool(expected) and hmac.compare_digest(received, expected)
