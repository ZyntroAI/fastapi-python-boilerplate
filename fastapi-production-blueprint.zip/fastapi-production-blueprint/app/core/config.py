import os
from dataclasses import dataclass

@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "fastapi-production-api")
    environment: str = os.getenv("ENVIRONMENT", "development")
    jwt_secret: str = os.getenv("JWT_SECRET", "")
    jwt_algorithm: str = os.getenv("JWT_ALGORITHM", "HS256")
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "15"))
    cookie_secure: bool = os.getenv("COOKIE_SECURE", "false").lower() == "true"
    oauth_client_id: str = os.getenv("OAUTH_CLIENT_ID", "")
    oauth_authorization_url: str = os.getenv("OAUTH_AUTHORIZATION_URL", "")
    oauth_redirect_uri: str = os.getenv("OAUTH_REDIRECT_URI", "")

settings = Settings()

if settings.environment == "production" and not settings.jwt_secret:
    raise RuntimeError("JWT_SECRET must be configured in production")
