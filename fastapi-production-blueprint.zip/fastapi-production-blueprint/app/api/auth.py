import secrets
from fastapi import APIRouter, HTTPException, Response
from app.core.config import settings
from app.core.security import create_access_token, verify_state

router = APIRouter()

@router.get("/login")
async def login():
    state = secrets.token_urlsafe(32)
    # Production: persist state server-side with a short TTL.
    response = {
        "authorization_url": (
            f"{settings.oauth_authorization_url}"
            f"?client_id={settings.oauth_client_id}"
            f"&redirect_uri={settings.oauth_redirect_uri}"
            f"&response_type=code&scope=openid%20profile%20email&state={state}"
        )
    }
    return response

@router.get("/callback")
async def callback(code: str, state: str, expected_state: str | None = None):
    if not expected_state or not verify_state(state, expected_state):
        raise HTTPException(status_code=400, detail="Invalid OAuth state")
    # Exchange `code` with the provider in a real deployment.
    token = create_access_token({"sub": "oauth-user"})
    response = Response(content='{"status":"authenticated"}', media_type="application/json")
    response.set_cookie(
        "access_token",
        token,
        httponly=True,
        secure=settings.cookie_secure,
        samesite="lax",
        max_age=settings.access_token_minutes * 60,
    )
    return response
