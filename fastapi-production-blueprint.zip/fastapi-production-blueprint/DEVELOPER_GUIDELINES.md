# Developer Guidelines

1. CI must fail on test, lint, type, or security failures.
2. Never commit real credentials, tokens, or production secrets.
3. Use environment variables or a secret manager.
4. OAuth state is mandatory and must be validated.
5. Do not put access tokens in URLs.
6. Keep application code independent from deployment manifests.
7. Prefer immutable container image tags.
8. Add unit and integration tests for security-sensitive code.
9. Keep Kubernetes workloads non-root and least-privileged.
10. Review dependency and container vulnerabilities before release.
